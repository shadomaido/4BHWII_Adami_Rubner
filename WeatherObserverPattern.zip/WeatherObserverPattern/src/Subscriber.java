public interface Subscriber {

    // PULL - Variante
    void getData(Data data);
}
